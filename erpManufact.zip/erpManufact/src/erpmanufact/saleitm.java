/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class saleitm {
            private String name;
         private String address;
          private String city;
           private String pin;
            private String contact1;
             private String contact2;
//             private String opebal;
           public saleitm(String Name,String Add,String City,String Pin,String Cont1, String Cont2){
        this.name=Name;
        this.address=Add;
        this.city=City;
        this.pin=Pin;
        this.contact1=Cont1;
        this.contact2=Cont2;
//        this.opebal=Opebal;
    }
   public String getName()
    {
        return name;
    }
   public String getSalerate()
    {
        return address;
    }
   public String getQuantity()
    {
        return city;
    }
   public String getDisc()
    {
        return pin;
    }
   public String getDiscamount()
    {
        return contact1;
    }
    public String getAmount()
    {
        return contact2;
    }
//    public String getOpnbal()
//    {
//        return opebal;
//    }
    
   
    


}
