/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class Ep {
    private String name;
         private String address;
          private String city;
           private String pin;
           public Ep(String Name,String Add,String City,String Pin){
        this.name=Name;
        this.address=Add;
        this.city=City;
        this.pin=Pin;
//        this.contact1=Cont1;
//        this.contact2=Cont2;
//        this.opebal=Opebal;
    }
   public String getName()
    {
        return name;
    }
   public String getType()
    {
        return address;
    }
   public String getSalerate()
    {
        return city;
    }
   public String getStock()
    {
        return pin;
    }
  
//    public String getO
    
}
