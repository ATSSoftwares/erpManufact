/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author new climax
 */
public class salevoucher extends javax.swing.JFrame {
Connection conn = null;
 ResultSet rs, rs1=null;
 PreparedStatement pst, pst1=null;
    /**
     * Creates new form salevoucher
     */
    public salevoucher() {
        initComponents();
             showDate();
           groupButton();
    ini();
      invoice();
    }
       private void groupButton(){
           conn = Javaconnection.ConnecrDb();
        ButtonGroup bg1=new ButtonGroup();
        //ButtonGroup bg2=new ButtonGroup();
        bg1.add(jRadioButton1);
        bg1.add(jRadioButton2);
        /*bg1.add(But12);
        bg1.add(But13);
        bg1.add(But14);
        bg2.add(But15);
        bg2.add(But16);
        bg2.add(But17);
        bg2.add(But18);*/
    }
    
    private void ini(){
        this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("abc.png")));
    }

     void showDate(){
        Date a = new Date();
        SimpleDateFormat s = new SimpleDateFormat("dd-MM-yyyy");
        date.setText(s.format(a));
      
}
     
     
     public void getSum(){
        DecimalFormat f = new DecimalFormat("##.00");
        float sum = 0;
        for(int i =0; i< jTable1.getRowCount(); i++)
        {
           sum = sum +  Float.parseFloat(jTable1.getValueAt(i, 4).toString()); //Integer.parseInt(jTable1.getValueAt(i, 6).toString());
        }
        jTextField8.setText(f.format(sum));
        
    }
    
    
     public void getSum1(){
        DecimalFormat f = new DecimalFormat("##.00");
        float sum = 0;
        for(int i =0; i< jTable1.getRowCount(); i++)
        {
           sum = sum +  Float.parseFloat(jTable1.getValueAt(i, 5).toString()); //Integer.parseInt(jTable1.getValueAt(i, 6).toString());
        }
        jTextField9.setText(f.format(sum));
        
    }

     public void invoice(){
         int a = 0, c=0;
         try {
                String b = "SELECT invoice FROM sale_voucher ORDER BY invoice DESC LIMIT 1;";
                 pst = conn.prepareStatement(b);
            rs=pst.executeQuery();
              while(rs.next()){
                  a = rs.getInt("invoice");
                   c = a+1;
                   inv.setText(String.valueOf(c));
              }
         } catch (Exception e) {
               JOptionPane.showMessageDialog(null, e);
         }
     }
     public ArrayList<saleitm> getUsersList()
    {
        ArrayList<saleitm> usersList= new ArrayList<saleitm>();
int b=0;
        try {

        String a = "SELECT `invoice_id` FROM `sale_voucher` WHERE `invoice`='"+inv.getText()+"'";
        pst = conn.prepareStatement(a);
        rs = pst.executeQuery();
       while(rs.next())
       {
           b = rs.getInt("invoice_id");
       }
            
        } 
        catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
        }
        String query= "SELECT * FROM `sale_finishgoods` JOIN `finished_goods` on `sale_finishgoods`.`fg_id` = `finished_goods`.`id` WHERE `invoice_id`='"+b+"'";
        Statement pst;
        ResultSet rs;
        try {
            pst = conn.createStatement();
            rs = pst.executeQuery(query);
          saleitm list;
            while(rs.next())
            {
                list = new  saleitm(rs.getString("finished_goods.name"),rs.getString("sale_rate"),rs.getString("quantity"),rs.getString("discount"),rs.getString("discounted_amount"),rs.getString("total"));
                usersList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return usersList;
        
    }
    public void Show_users_in_JTable()
    {
        ArrayList<saleitm> list = getUsersList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        Object[] row = new Object[7];
        for (int i = 0; i< list.size();i++)
        {
            row[0]= list.get(i).getName();
              row[1]= list.get(i).getSalerate();
                row[2]= list.get(i).getQuantity();
                  row[3]= list.get(i).getDisc();
            row[4]= list.get(i).getDiscamount();
            row[5]= list.get(i).getAmount();
         //   row[6]= list.get(i).getOpnbal();
            
           // System.out.println(row[0]);
            model.addRow(row);
        }
    }
     public ArrayList<saleitm> getUsersList1()
    {
        ArrayList<saleitm> usersList= new ArrayList<saleitm>();
int b=0;
        try {

        String a = "SELECT `invoice_id` FROM `sale_voucher` WHERE `invoice`='"+inv.getText()+"'";
        pst = conn.prepareStatement(a);
        rs = pst.executeQuery();
       while(rs.next())
       {
           b = rs.getInt("invoice_id");
       }
            
        } 
        catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
        }
        String query= "SELECT * FROM `sale_fgwstg` JOIN `finished_goods` on `sale_fgwstg`.`fg_id` = `finished_goods`.`id` WHERE `invoice_id`='"+b+"'";
        Statement pst;
        ResultSet rs;
        try {
            pst = conn.createStatement();
            rs = pst.executeQuery(query);
          saleitm list;
            while(rs.next())
            {
                list = new  saleitm(rs.getString("finished_goods.name"),rs.getString("sale_rate"),rs.getString("quantity"),rs.getString("disc"),rs.getString("discounted_amount"),rs.getString("total"));
                usersList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return usersList;
        
    }
    public void Show_users_in_JTable1()
    {
        ArrayList<saleitm> list = getUsersList1();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        Object[] row = new Object[7];
        for (int i = 0; i< list.size();i++)
        {
            row[0]= list.get(i).getName()+"(wstg)";
              row[1]= list.get(i).getSalerate();
                row[2]= list.get(i).getQuantity();
                  row[3]= list.get(i).getDisc();
            row[4]= list.get(i).getDiscamount();
            row[5]= list.get(i).getAmount();
         //   row[6]= list.get(i).getOpnbal();
            
           // System.out.println(row[0]);
            model.addRow(row);
        }
    }
     public ArrayList<saleitm> getUsersList2()
    {
        ArrayList<saleitm> usersList= new ArrayList<saleitm>();
int b=0;
        try {

        String a = "SELECT `invoice_id` FROM `sale_voucher` WHERE `invoice`='"+inv.getText()+"'";
        pst = conn.prepareStatement(a);
        rs = pst.executeQuery();
       while(rs.next())
       {
           b = rs.getInt("invoice_id");
       }
            
        } 
        catch (Exception e) {
        JOptionPane.showMessageDialog(null, date);
        }
        String query= "SELECT * FROM `sale_packs` JOIN `pack_items` on `sale_packs`.`pack_id` = `pack_items`.`id` WHERE `invoice_id`='"+b+"'";
        Statement pst;
        ResultSet rs;
        try {
            pst = conn.createStatement();
            rs = pst.executeQuery(query);
          saleitm list;
            while(rs.next())
            {
                list = new  saleitm(rs.getString("pack_items.name"),rs.getString("sale_rate"),rs.getString("quantity"),rs.getString("disc"),rs.getString("discounted_amount"),rs.getString("total"));
                usersList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return usersList;
        
    }
    public void Show_users_in_JTable2()
    {
        ArrayList<saleitm> list = getUsersList2();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        Object[] row = new Object[7];
        for (int i = 0; i< list.size();i++)
        {
            row[0]= list.get(i).getName();
              row[1]= list.get(i).getSalerate();
                row[2]= list.get(i).getQuantity();
                  row[3]= list.get(i).getDisc();
            row[4]= list.get(i).getDiscamount();
            row[5]= list.get(i).getAmount();
         //   row[6]= list.get(i).getOpnbal();
            
           // System.out.println(row[0]);
            model.addRow(row);
        }
    }
       public ArrayList<saleitm> getUsersList3()
    {
        ArrayList<saleitm> usersList= new ArrayList<saleitm>();
int b=0;
        try {

        String a = "SELECT `invoice_id` FROM `sale_voucher` WHERE `invoice`='"+inv.getText()+"'";
        pst = conn.prepareStatement(a);
        rs = pst.executeQuery();
       while(rs.next())
       {
           b = rs.getInt("invoice_id");
       }
            
        } 
        catch (Exception e) {
        JOptionPane.showMessageDialog(null, date);
        }
        String query= "SELECT * FROM `sale_ritmwstg` JOIN `rawitemweghit` on `sale_ritmwstg`.`rwmt_id` = `rawitemweghit`.`Id` WHERE `invoice_id`='"+b+"'";
        Statement pst;
        ResultSet rs;
        try {
            pst = conn.createStatement();
            rs = pst.executeQuery(query);
          saleitm list;
            while(rs.next())
            {
                list = new  saleitm(rs.getString("rawitemweghit.Itemname"),rs.getString("sale_rate"),rs.getString("quantity"),rs.getString("disc"),rs.getString("discounted_amount"),rs.getString("total"));
                usersList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return usersList;
        
    }
    public void Show_users_in_JTable3()
    {
        ArrayList<saleitm> list = getUsersList3();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        Object[] row = new Object[7];
        for (int i = 0; i< list.size();i++)
        {
            row[0]= list.get(i).getName();
              row[1]= list.get(i).getSalerate();
                row[2]= list.get(i).getQuantity();
                  row[3]= list.get(i).getDisc();
            row[4]= list.get(i).getDiscamount();
            row[5]= list.get(i).getAmount();
         //   row[6]= list.get(i).getOpnbal();
            
           // System.out.println(row[0]);
            model.addRow(row);
        }
    }
      public ArrayList<saleitm> getUsersList4()
    {
        ArrayList<saleitm> usersList= new ArrayList<saleitm>();
int b=0;
        try {

        String a = "SELECT `invoice_id` FROM `sale_voucher` WHERE `invoice`='"+inv.getText()+"'";
        pst = conn.prepareStatement(a);
        rs = pst.executeQuery();
       while(rs.next())
       {
           b = rs.getInt("invoice_id");
       }
            
        } 
        catch (Exception e) {
        JOptionPane.showMessageDialog(null, date);
        }
        String query= "SELECT * FROM `sale_wholesale` JOIN `wsitem` on `sale_wholesale`.`wsitem_id` = `wsitem`.`item_id` WHERE `invoice_id`='"+b+"'";
        Statement pst;
        ResultSet rs;
        try {
            pst = conn.createStatement();
            rs = pst.executeQuery(query);
          saleitm list;
            while(rs.next())
            {
                list = new  saleitm(rs.getString("wsitem.item_name"),rs.getString("sale_rate"),rs.getString("quantity"),rs.getString("disc"),rs.getString("discounted_amount"),rs.getString("total"));
                usersList.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return usersList;
        
    }
    public void Show_users_in_JTable4()
    {
        ArrayList<saleitm> list = getUsersList4();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        Object[] row = new Object[7];
        for (int i = 0; i< list.size();i++)
        {
            row[0]= list.get(i).getName();
              row[1]= list.get(i).getSalerate();
                row[2]= list.get(i).getQuantity();
                  row[3]= list.get(i).getDisc();
            row[4]= list.get(i).getDiscamount();
            row[5]= list.get(i).getAmount();
         //   row[6]= list.get(i).getOpnbal();
            
           // System.out.println(row[0]);
            model.addRow(row);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        inv = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jTextField8 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jTextField14 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jTextField15 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Sale Voucher");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 175, 239));

        jLabel3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Date:");

        date.setEditable(false);
        date.setBackground(new java.awt.Color(255, 255, 255));
        date.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        date.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dateMouseClicked(evt);
            }
        });
        date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dateActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Customer Name:");

        jTextField2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField2KeyPressed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Address:");

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setWrapStyleWord(true);
        jTextArea1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jScrollPane1.setViewportView(jTextArea1);

        jLabel7.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("City:");

        jLabel8.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Pin Code:");

        jTextField5.setEditable(false);
        jTextField5.setBackground(new java.awt.Color(255, 255, 255));
        jTextField5.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });

        jTextField6.setEditable(false);
        jTextField6.setBackground(new java.awt.Color(255, 255, 255));
        jTextField6.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel9.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Contacts:");

        jTextField3.setEditable(false);
        jTextField3.setBackground(new java.awt.Color(255, 255, 255));
        jTextField3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField3KeyPressed(evt);
            }
        });

        jTextField4.setEditable(false);
        jTextField4.setBackground(new java.awt.Color(255, 255, 255));
        jTextField4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTextField4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField4KeyPressed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Sale Voucher");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Invoice No.:");

        inv.setBackground(new java.awt.Color(255, 255, 255));
        inv.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        inv.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        inv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTextField8.setEditable(false);
        jTextField8.setBackground(new java.awt.Color(0, 175, 239));
        jTextField8.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextField8.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 175, 239));
        jLabel11.setText("Amount:");

        jTextField10.setEditable(false);
        jTextField10.setBackground(new java.awt.Color(0, 175, 239));
        jTextField10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextField10.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 175, 239));
        jLabel14.setText("Output Vat@");

        jTextField9.setEditable(false);
        jTextField9.setBackground(new java.awt.Color(0, 175, 239));
        jTextField9.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextField9.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 175, 239));
        jLabel13.setText("Grand Total:");

        jTextField11.setEditable(false);
        jTextField11.setBackground(new java.awt.Color(0, 175, 239));
        jTextField11.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextField11.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 175, 239));
        jLabel16.setText("Output Additional@");

        jTextField12.setEditable(false);
        jTextField12.setBackground(new java.awt.Color(0, 175, 239));
        jTextField12.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextField12.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 175, 239));
        jLabel17.setText("Round Off:");

        jLabel18.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N

        jLabel19.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N

        jLabel20.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 175, 239));
        jLabel20.setText("Prev. Balance:");

        jTextField14.setEditable(false);
        jTextField14.setBackground(new java.awt.Color(0, 175, 239));
        jTextField14.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextField14.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField14ActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 175, 239));
        jLabel21.setText("Amount to Recieve:");

        jTextField15.setBackground(new java.awt.Color(0, 175, 239));
        jTextField15.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextField15.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField15ActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 175, 239));
        jLabel22.setText("Reciept:");

        jTextField13.setEditable(false);
        jTextField13.setBackground(new java.awt.Color(0, 175, 239));
        jTextField13.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTextField13.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                        .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                            .addComponent(jTextField12, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22))
                        .addGap(89, 89, 89)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField15, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField14, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField13))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel19))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel15.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 175, 239));
        jLabel15.setText("Vat Type:");

        jRadioButton1.setBackground(new java.awt.Color(255, 255, 255));
        jRadioButton1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jRadioButton1.setText("14.5");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        jRadioButton2.setBackground(new java.awt.Color(255, 255, 255));
        jRadioButton2.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        jRadioButton2.setText("5");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton2)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Sale Rate", "Qnt./Wgt.", "Disc%", "Discounted Am.", "Amount"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton2.setMnemonic('s');
        jButton2.setText("Add Items To Sale");
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton3.setMnemonic('s');
        jButton3.setText("Show");
        jButton3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton4.setMnemonic('c');
        jButton4.setText("Save");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton5.setMnemonic('c');
        jButton5.setText("Cancel");
        jButton5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(129, 129, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel12)
                        .addGap(153, 153, 153)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(inv, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)))
                .addGap(34, 34, 34))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 984, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(147, 147, 147)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(80, 80, 80)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2)
                            .addComponent(jButton3)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(inv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton4)
                            .addComponent(jButton5))
                        .addGap(27, 27, 27))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void dateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dateMouseClicked
        date.setEditable(true);        // TODO add your handling code here:
        date.setText(null);
    }//GEN-LAST:event_dateMouseClicked

    private void dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dateActionPerformed

    }//GEN-LAST:event_dateActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField2KeyPressed
if(evt.getKeyCode()==KeyEvent.VK_INSERT)    {
            Customers a = new Customers();
            a.setVisible(true);
        }
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            selcus a = new selcus();
            a.setVisible(true);
        }// TODO
        
        
    }//GEN-LAST:event_jTextField2KeyPressed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField3KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3KeyPressed

    private void jTextField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField4KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4KeyPressed

    private void invActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_invActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        jLabel18.setText("12.5%");
       
        jLabel19.setText("2%");
        DecimalFormat f = new DecimalFormat("##.00");
        double a = Double.parseDouble(jTextField8.getText());
         double b = Double.parseDouble(jTextField9.getText());
         double c = a*12.5/100;
        jTextField10.setText(f.format(c));
        double d = a*2/100;
        jTextField11.setText(f.format(d));
       double k = Double.parseDouble(jTextField8.getText())+Double.parseDouble(jTextField10.getText())+Double.parseDouble(jTextField11.getText());
double l;
if (k<b){
    l=b-k;
    jTextField12.setText("(+)"+f.format(l));
}
else{
    l=k-b;
    jTextField12.setText("(-)"+f.format(l));
}
double m = Double.parseDouble(jTextField13.getText());
double n = m + b ;
jTextField14.setText(f.format(n));
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
  jLabel18.setText("4%");
        jLabel19.setText("1%");
         DecimalFormat f = new DecimalFormat("##.00");
        double a = Double.parseDouble(jTextField8.getText());
         double b = Double.parseDouble(jTextField9.getText());
         double c = a*4/100;
        jTextField10.setText(f.format(c));
        double d = a*1/100;
        jTextField11.setText(f.format(d));
       double k = Double.parseDouble(jTextField8.getText())+Double.parseDouble(jTextField10.getText())+Double.parseDouble(jTextField11.getText());
double l;
if (k<b){
    l=b-k;
    jTextField12.setText("(+)"+f.format(l));
}
else{
    l=k-b;
    jTextField12.setText("(-)"+f.format(l));
}
double m = Double.parseDouble(jTextField13.getText());
double n = m + b ;
jTextField14.setText(f.format(n));
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
Show_users_in_JTable();       
Show_users_in_JTable1();
Show_users_in_JTable2();
Show_users_in_JTable3();
Show_users_in_JTable4();
getSum();
getSum1();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      int Id =0, Id2 = 0, y = 0;
      int a = Integer.parseInt(inv.getText());
      String d = date.getText();
        try {
               String z = "SELECT `Id` FROM `coustomer` WHERE `Cutname`='"+jTextField2.getText()+"' ";
                pst = conn.prepareStatement(z);
             rs=pst.executeQuery();
            while(rs.next()){
                Id2 = rs.getInt("Id");
            }
             String k = "SELECT `invoice` FROM `sale_voucher`";
              pst = conn.prepareStatement(k);
             rs=pst.executeQuery();
            
               while(rs.next()){
                Id = rs.getInt("invoice");
          //     System.out.println(Id);
               if(Id==a){
//                     saletypeselection b = new saletypeselection();
//b.setVisible(true);
                   y= a;
               }

               
              }
               if(y==a){
                   saletypeselection.date1 = date.getText();
                   saletypeselection.fg = inv.getText();
                    saletypeselection b = new saletypeselection();
b.setVisible(true);

               }
               else{
                     pst=(PreparedStatement) conn.prepareStatement("INSERT INTO `sale_voucher` (`invoice`, `date`, `customer_id`) VALUES('"+a+"','"+d+"','"+Id2+"')");
          int i = pst.executeUpdate();
                      if(i>0){
                           saletypeselection.date1 = date.getText();
                         saletypeselection.fg = inv.getText();
                             saletypeselection b = new saletypeselection();
b.setVisible(true);
 
                      }
                      else{
                           JOptionPane.showMessageDialog(null,"Data is not saved");
                      }
               }
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
        }
        
        
      // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int Id2=0, f=0, h=0;
        long k=0, m=0;
                try {

        String d = "SELECT `invoice_id` FROM `sale_voucher` WHERE `invoice`='"+inv.getText()+"'";
        pst = conn.prepareStatement(d);
        rs = pst.executeQuery();
       while(rs.next())
       {
           f = rs.getInt("invoice_id");
       }
            
      
        float a = Float.parseFloat(jTextField14.getText());
        float b = Float.parseFloat(jTextField15.getText());
        float c = a -b ;
        try {
             String z = "SELECT `Id` FROM `coustomer` WHERE `Cutname`='"+jTextField2.getText()+"' ";
                pst = conn.prepareStatement(z);
             rs=pst.executeQuery();
            while(rs.next()){
                Id2 = rs.getInt("Id");
            }
          
            pst=(PreparedStatement) conn.prepareStatement("UPDATE `coustomer` SET `Cutopenbal`='"+c+"' WHERE `Id`='"+Id2+"'");
              int i = pst.executeUpdate();
            if(i>0){
         
                 pst=(PreparedStatement) conn.prepareStatement("INSERT INTO `salevoucher_am` (`invoice_id`, `amount`, `out_vat`,`out_add`,`roff`,`grand_total`,`reciept`) VALUES('"+f+"','"+jTextField8.getText()+"','"+jTextField10.getText()+"','"+jTextField11.getText()+"','"+jTextField12.getText()+"','"+jTextField9.getText()+"','"+jTextField15.getText()+"')");
                  int j = pst.executeUpdate();
                  if(j>0){
                      String g ="SELECT `fg_id`, `quantity` FROM `sale_fgwstg` WHERE `invoice_id`='"+f+"'";
                      pst = conn.prepareStatement(g);
        rs = pst.executeQuery();
       while(rs.next()){
           h= rs.getInt("fg_id");
           k= rs.getLong("quantity");
           if(h>0){
           String l = "SELECT `wstg` FROM `finished_goods` WHERE `id`='"+h+"'";
           pst1 = conn.prepareStatement(l);
           rs1= pst1.executeQuery();
           while(rs1.next()){
               m = rs1.getLong("wstg");
           }
           long n = m - k;
           pst1=(PreparedStatement) conn.prepareStatement("UPDATE `finished_goods` SET `wstg`='"+n+"' WHERE `id`='"+h+"'"); 
           int o = pst1.executeUpdate();
           if(o>0){
               
           }
           }
       }
       int q =0;
       long r = 0, t=0;
                    String p ="SELECT `fg_id`, `quantity` FROM `sale_finishgoods` WHERE `invoice_id`='"+f+"'";
                      pst = conn.prepareStatement(p);
        rs = pst.executeQuery();
       while(rs.next()){
           q= rs.getInt("fg_id");
           r= rs.getLong("quantity");
           if(q>0){
           String s = "SELECT `avalible_stock` FROM `finished_goods` WHERE `id`='"+q+"'";
           pst1 = conn.prepareStatement(s);
           rs1= pst1.executeQuery();
           while(rs1.next()){
               t = rs1.getLong("avalible_stock");
           }
           long u = t - r;
           pst1=(PreparedStatement) conn.prepareStatement("UPDATE `finished_goods` SET `avalible_stock`='"+u+"' WHERE `id`='"+q+"'"); 
           int o = pst1.executeUpdate();
           if(o>0){
               
           }
           }
       }
        int v =0;
       long w = 0, x=0;
                    String y ="SELECT `pack_id`, `quantity` FROM `sale_packs` WHERE `invoice_id`='"+f+"'";
                      pst = conn.prepareStatement(y);
        rs = pst.executeQuery();
       while(rs.next()){
           v= rs.getInt("pack_id");
           w= rs.getLong("quantity");
           if(v>0){
           String s = "SELECT `stock` FROM `pack_items` WHERE `id`='"+v+"'";
           pst1 = conn.prepareStatement(s);
           rs1= pst1.executeQuery();
           while(rs1.next()){
               x = rs1.getLong("stock");
           }
           long aa = x - w;
           pst1=(PreparedStatement) conn.prepareStatement("UPDATE `pack_items` SET `stock`='"+aa+"' WHERE `id`='"+v+"'"); 
           int o = pst1.executeUpdate();
           if(o>0){
               
           }
           }
       }
        int ab =0;
       long ac = 0, ad=0;
                    String ae ="SELECT `rwmt_id`, `quantity` FROM `sale_ritmwstg` WHERE `invoice_id`='"+f+"'";
                      pst = conn.prepareStatement(ae);
        rs = pst.executeQuery();
       while(rs.next()){
           ab= rs.getInt("rwmt_id");
           ac= rs.getLong("quantity");
           if(ab>0){
           String s = "SELECT `wstg_ammount` FROM `rawitemweghit` WHERE `Id`='"+ab+"'";
           pst1 = conn.prepareStatement(s);
           rs1= pst1.executeQuery();
           while(rs1.next()){
               ad = rs1.getLong("wstg_ammount");
           }
           long af = ad - ac;
           pst1=(PreparedStatement) conn.prepareStatement("UPDATE `rawitemweghit` SET `wstg_ammount`='"+af+"' WHERE `Id`='"+ab+"'"); 
           int o = pst1.executeUpdate();
           if(o>0){
               
           }
           }
       }
       int ag =0;
       long ah = 0, ai=0;
                    String aj ="SELECT `wsitem_id`, `quantity` FROM `sale_wholesale` WHERE `invoice_id`='"+f+"'";
                      pst = conn.prepareStatement(aj);
        rs = pst.executeQuery();
       while(rs.next()){
           ag= rs.getInt("wsitem_id");
           ah= rs.getLong("quantity");
           if(ag>0){
           String s = "SELECT `stock` FROM `wsitem` WHERE `item_id`='"+ag+"'";
           pst1 = conn.prepareStatement(s);
           rs1= pst1.executeQuery();
           while(rs1.next()){
               ai = rs1.getLong("stock");
           }
           long ak = ai - ah;
           pst1=(PreparedStatement) conn.prepareStatement("UPDATE `wsitem` SET `stock`='"+ak+"' WHERE `item_id`='"+ag+"'"); 
           int o = pst1.executeUpdate();
           if(o>0){
               
           }
           }
       }
                          invsalevoucher al = new invsalevoucher();
                   al.setVisible(true);
                   invsalevoucher.jLabel8.setText(inv.getText());
                   invsalevoucher.jLabel9.setText(jTextField15.getText());
                   dispose();

                  }
            }
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null, e);
        }
      } 
        catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
     int b = 0;
        try {

        String a = "SELECT `invoice_id` FROM `sale_voucher` WHERE `invoice`='"+inv.getText()+"'";
        pst = conn.prepareStatement(a);
        rs = pst.executeQuery();
       while(rs.next())
       {
           b = rs.getInt("invoice_id");
           
       }
     //  System.out.println(String.valueOf(b));
        if(b<=0){
           dispose ();
        }
        else{
             pst=(PreparedStatement) conn.prepareStatement("DELETE FROM `sale_voucher` WHERE `invoice_id`='"+b+"'");
          int i = pst.executeUpdate();
            if(i>0){
                       dispose();
                      }
                      else{
                           JOptionPane.showMessageDialog(null,"Error!");
                      }
        }
        } 
        catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
        }
        
       
        
        
        
        
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(salevoucher.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(salevoucher.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(salevoucher.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(salevoucher.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new salevoucher().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField date;
    private javax.swing.JTextField inv;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    public static javax.swing.JTable jTable1;
    public static javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    public static javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    public static javax.swing.JTextField jTextField2;
    public static javax.swing.JTextField jTextField3;
    public static javax.swing.JTextField jTextField4;
    public static javax.swing.JTextField jTextField5;
    public static javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
