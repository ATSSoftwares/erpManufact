/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class wg {
    private String  name;
    private String  type;
    private String  stock;
    private String  rate;
    public wg(String Name,String Type,String Stock,String Rate)
    {
        this.name=Name;
        this.type=Type;
        this.stock=Stock;
        this.rate=Rate;
       // this.wgt=Wgt;
    
}
      public String getName()
    {
        return name;
    }
      public String getType()
    {
        return type;
    }
      public String getStock()
    {
        return stock;
    }
      public String getRate()
    {
        return rate;
    }
    
}
