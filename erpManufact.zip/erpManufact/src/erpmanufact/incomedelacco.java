/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class incomedelacco {
    
    private String  acc_name;
    
    public incomedelacco(String acc_name)
    {
        this.acc_name=acc_name;
       // this.acc_bal=acc_bal;
        
        
    }

//    expacolist(String string) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
   public String getName()
    {
        return acc_name;
    }
    
    
}
