/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class packtypelist {
    private String  name;
     public packtypelist(String Name)
    {
        this.name=Name;
    
}
      public String getName()
    {
        return name;
    }
}
