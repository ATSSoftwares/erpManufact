/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class selectacc {
        private String name;
         private String address;
          private String city;
           private String pin;
            private String contact1;
             private String contact2;
             private String opebal;
           public selectacc(String Name,String Add,String City,String Pin,String Cont1,String Cont2,String Opebal){
        this.name=Name;
        this.address=Add;
        this.city=City;
        this.pin=Pin;
        this.contact1=Cont1;
        this.contact2=Cont2;
        this.opebal=Opebal;
    }
   public String getName()
    {
        return name;
    }
   public String getAddress()
    {
        return address;
    }
   public String getCity()
    {
        return city;
    }
   public String getPin()
    {
        return pin;
    }
   public String getContact1()
    {
        return contact1;
    }public String getContact2()
    {
        return contact2;
    }
    public String getOpnbal()
    {
        return opebal;
    }
    
   
    

    
}
