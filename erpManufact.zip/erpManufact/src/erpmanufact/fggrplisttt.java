/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class fggrplisttt {
    private String  name;
    private String  group;
    private String  stock;
    private String  wgt;

     public fggrplisttt(String Name,String Group,String Stock,String Wgt)
    {
        this.name=Name;
        this.group=Group;
        this.stock=Stock;
        this.wgt=Wgt;
    
}
      public String getName()
    {
        return name;
    }
      public String getGroup()
    {
        return group;
    }
      public String getStock()
    {
        return stock;
    }
      public String getWgt()
    {
        return wgt;
    }
    
}
