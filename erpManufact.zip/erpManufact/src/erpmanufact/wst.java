/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class wst {
    private String  name;
   // private String  packet;
    private String  stock;
   // private String  value;
     public wst(String Name,String Stock)
    {
        this.name=Name;
       // this.packet=Packet;
        this.stock=Stock;
       // this.value=Value;
       // this.wgt=Wgt;
    
}
      public String getName()
    {
        return name;
    }
     
      public String getStock()
    {
        return stock;
    }
     
    
    
}
