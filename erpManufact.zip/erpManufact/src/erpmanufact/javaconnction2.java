/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
import java.sql.*;
import javax.swing.*;

public class javaconnction2 {
    
    
    Connection conn1=null;
    public static Connection ConnecrDb(){
     try {
            Class.forName("com.mysql.jdbc.Driver");
            //Connection conn= DriverManager.getConnection("jdbc:mysql://localhost/erpmanufact","root","admin");
            Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost/erpmanufact","root","computer");
            return conn1;
            
        } 
        
        catch (Exception e) {
            
             JOptionPane.showMessageDialog(null, e);
             return null;
        }
        
        
        
    
    
}
}
    

