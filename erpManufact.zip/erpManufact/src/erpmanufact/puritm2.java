/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class puritm2 {
    private String  name;
    private String  packet;
    private String  stock;
    private String  value;
    public puritm2(String Name,String Packet,String Stock,String Value)
    {
        this.name=Name;
        this.packet=Packet;
        this.stock=Stock;
        this.value=Value;
       // this.wgt=Wgt;
    
}
      public String getName()
    {
        return name;
    }
      public String getPacket()
    {
        return packet;
    }
      public String getStock()
    {
        return stock;
    }
      public String getValue()
    {
        return value;
    }
    
    
}
