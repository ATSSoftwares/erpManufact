/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpmanufact;

/**
 *
 * @author sandeep
 */
public class custtypelist {
    private String name;
     private String city;
    private String contact1;
    private String contact2;
    public custtypelist(String Name,String City,String Contact1,String Contact2)
    {
        this.name=Name;
        this.city=City;
        this.contact1=Contact1;
        this.contact2=Contact2;
        
    }
   public String getName()
    {
        return name;
    }
    
   
   
    
    public String getCity()
    {
      return city;  
    }
    
    public String getContact1()
    {
      return contact1;  
    }
    public String getContact2()
    {
      return contact2;  
    }
    
}
